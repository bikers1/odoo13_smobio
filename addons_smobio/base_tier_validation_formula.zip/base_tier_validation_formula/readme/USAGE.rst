To define the domain,
* By python code choose the **Formula** option in the Definition field.
* By both domain and python code, choose the **Domain & Formula** option in the Definition field.

To define the reviewers by python code choose **Python Expression** option in the Validated by field.
